--Create table for Retirement Titles
SELECT
	e.emp_no,
    e.first_name,
    e.last_name,
    titles.title,
    titles.from_date,
    titles.to_date
INTO retirement_titles
FROM employees as e
LEFT JOIN titles
ON e.emp_no = titles.emp_no
WHERE (birth_date BETWEEN '1952-01-01' AND '1955-12-31')
ORDER BY emp_no, emp_no DESC;

-- Use Distinct with Orderby to remove duplicate rows
SELECT DISTINCT ON (emp_no)
	e.emp_no,
    e.first_name,
    e.last_name,
    titles.title,
    titles.from_date,
    titles.to_date
INTO unique_titles
FROM employees as e
LEFT JOIN titles
ON e.emp_no = titles.emp_no
WHERE (birth_date BETWEEN '1952-01-01' AND '1955-12-31')
ORDER BY emp_no, emp_no DESC;

-- Number of employees retiring by title
SELECT COUNT (title), title
INTO retiring_titles
FROM unique_titles
GROUP BY title
ORDER BY count DESC;

-- Total number of retiring employees
SELECT COUNT (emp_no)
FROM unique_titles

--Create table for Mentorship Eligibility
SELECT DISTINCT ON (emp_no)
	e.emp_no,
    e.first_name,
    e.last_name,
	e.birth_date,
    de.from_date,
    de.to_date,
	titles.title
INTO mentorship_eligibility
FROM employees as e
LEFT JOIN dept_emp as de
ON (e.emp_no = de.emp_no)
INNER JOIN titles
ON (de.emp_no = titles.emp_no)
WHERE (e.birth_date BETWEEN '1965-01-01' AND '1965-12-31')
AND de.to_date = ('9999-01-01')
ORDER BY emp_no, emp_no DESC;

--Number of employees eligible for mentorship program by title
SELECT COUNT (emp_no), title
INTO mentorship_titles
FROM mentorship_eligibility
GROUP BY title
ORDER BY count DESC

-- Total number of eligible employees
SELECT COUNT (emp_no)
FROM mentorship_eligibility